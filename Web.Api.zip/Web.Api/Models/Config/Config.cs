﻿namespace Web.Api.Models.Config
{
    public class Config
    {
        public string VersionInfo { get; set; }
    }
}
